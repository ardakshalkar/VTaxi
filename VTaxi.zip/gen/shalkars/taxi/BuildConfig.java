/** Automatically generated file. DO NOT MODIFY */
package shalkars.taxi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}