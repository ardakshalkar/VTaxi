package shalkars.taxi;

import java.util.List;
import shalkars.taxi.R;


import com.google.analytics.tracking.android.EasyTracker;
import com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import android.os.AsyncTask;
import android.os.Bundle;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;
import android.support.v4.app.NavUtils;

public class AddFeedbackActivity extends Activity {
	int addcount =0;
    @TargetApi(11)
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_feedback);
        //getActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public void onStart() {
      super.onStart();
      EasyTracker.getInstance().activityStart(this); // Add this method.
    }

    @Override
    public void onStop() {
      super.onStop();
      EasyTracker.getInstance().activityStop(this); // Add this method.
    }
    public void cancel(View view){
    	Intent showContent = new Intent(getApplicationContext(),TaxiProfileActivity.class);
		startActivity(showContent);
    }
    private class AddFeedbackTask extends AsyncTask<String, Void, String>{
    	@Override
    	protected void onPostExecute(String result){
    		if (result.equals("NAMEORRATING")){
    			Toast.makeText(getApplicationContext(), "может вы хотите ввести рейтинг или ваше имя?",Toast.LENGTH_LONG).show();
    		}
    	}
		@Override
		protected String doInBackground(String... params) {
			Log.d("started", "started");
			EditText et=(EditText)findViewById(R.id.feedbacktext);
			RatingBar rb=(RatingBar)findViewById(R.id.feedbackrating);
			EditText etowner=(EditText)findViewById(R.id.feedbackowner);
			if (et.getText().length()>0){
				if ((rb.getRating()>.0f&&etowner.getText().length()>0)||addcount==1){
					addcount=0;
					Datas.feedbackrating = rb.getRating();
					Datas.feedbacktext = et.getText();
					Parse.initialize(AddFeedbackActivity.this, "wYwjvSd8hs05UPISchXs1wEkIxJ7orGX43V1YaF0", "VSb0LZRRBp0lFU7Byd04F3YHHdArTdjgJr3a4iHV");
					
					ParseUser.enableAutomaticUser();
					ParseACL defaultACL = new ParseACL();
					//defaultACL.setPublicReadAccess(true);
					ParseACL.setDefaultACL(defaultACL, true);
					ParseObject feedback=new ParseObject("Review");
					String owner = "Аноним";
					if (etowner.getText().length()>0){
						owner=etowner.getText().toString();
					}
					feedback.put("owner", owner);
					feedback.put("content", et.getText().toString());
					feedback.put("rating",(int)rb.getRating());
					feedback.put("taxiId", Datas.selectedTaxi.id);
					feedback.saveInBackground();
					ParseQuery query = new ParseQuery("taxi");
					try{
						ParseObject taxi=query.get(Datas.selectedTaxi.id);
						taxi.increment("reviews");
						if (rb.getRating()>.0f){
							taxi.increment("ratingCount");
							taxi.increment("ratingTotal", (int)rb.getRating());
						}
						taxi.saveInBackground();
					}catch(ParseException pe){pe.printStackTrace();Log.d("parse", pe.toString());}
					ParseQuery subquery = new ParseQuery("Review");
					subquery.whereEqualTo("taxiId",Datas.selectedTaxi.id);
					subquery.orderByDescending("createdAt");
					try{
						List<ParseObject> ratings = subquery.find();
						Datas.updateFeedbacks(ratings);
						
					}catch (Exception e){e.printStackTrace();}
				    Intent showContent = new Intent(getApplicationContext(),TaxiProfileActivity.class);
			   		startActivity(showContent);
				}
				else if (addcount==0){
					addcount++;
					return "NAMEORRATING";
				}
			}
			else {
				Toast.makeText(getApplicationContext(), "введите отзыв", Toast.LENGTH_LONG).show();
			}
			return "NOTHING";
		}
    }
    public void addFeedback(View view){
    	AddFeedbackTask task = new AddFeedbackTask();
        task.execute(new String[] { String.valueOf(Datas.selectedTaxi) });
    	
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_add_feedback, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
